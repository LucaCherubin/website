                            MEDIEVAL LIFE

# Overview
Medieval Life is an engaging text-based adventure game set in the Middle Ages. Players can recruit heroes, embark on hunting expeditions, gamble at taverns, and rise through the ranks to become legendary figures in a medieval world.

# Features
- **Hero Recruitment**: Add new heroes to your team, each starting at level 1 with 100 coins.
- **Hunting Expeditions**: Face various monsters to gain experience and coins.
- **Tavern Gambling**: Test your luck with a dice-rolling mini-game.
- **Healing System**: Restore your heroes' health to continue their adventures.
- **Leaderboard**: Track your heroes' progress and compare their stats.
- **In-game Rules**: Access game instructions at any time.

# How to Play
1. Download the Medieval_Life folder.
2. Double-click the `medieval_life.exe` file to run the game.
3. Follow the on-screen prompts to navigate through the game.

# Game Commands
- `a`: Recruit a new hero
- `b`: Go on a hunting expedition
- `c`: Gamble at the tavern
- `d`: Seek healing for your heroes
- `e`: View the heroes' leaderboard
- `f`: Consult the game rules
- `g`: Quit the game

# Design Principles

## 1. Abstraction
**Explanation**: The class Action is an abstract base class that 
defines the common interface for all child classes. It declares 
abstract methods (__init__ and start) that must be implemented by the 
concrete subclasses.
**Where Found**: 
- `Action` is an abstract class with two abstract methods.

## 2. Inheritance
**Explanation**: Inheritance is a mechanism where a new class inherits properties and behaviors (methods) from an existing class.
**Where Found**: 
- The `Hunt` and `Gamble` classes inherit from the `Action` class, reusing and extending its functionality.

## 3. Polymorphism
**Explanation**: Polymorphism allows objects of different classes to be treated as objects of a common superclass. It is achieved through method overriding and interfaces.
**Where Found**: 
- The `start` method in the `Action` class is overridden by the `Hunt` and `Gamble` classes to provide specific implementations for these actions.


# System Requirements
- Windows operating system
- Python 3.x

# Development
Medieval Life was developed using Python.

# Author
Luca Cherubin

# Version
1.0.0

# CONTACTS:
lucacherubin27@gmail.com



Enjoy your medieval adventure!