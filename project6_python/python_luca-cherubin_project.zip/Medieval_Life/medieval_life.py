#!/usr/bin/env python3
#
# File: medieval_life.py
# Description: Medieval Life Game. The program allows players to recruit heroes, embark on hunting expeditions,
#              gamble at the tavern, seek healing, and view the leaderboard of heroes. Players can gain experience
#              and level up by defeating monsters. The game also provides a detailed rules section for guidance.
# Author: Luca Cherubin
#

from abc import ABC, abstractmethod  # Needed to create abstract classes/methods
import random  # Needed to generate random numbers

class Game:
    """
        This is the main class representing the Medieval Life game. It manages the game's flow,
        player interactions, and various game actions.

        The game allows players to recruit heroes, go on hunting expeditions, gamble at the tavern,
        heal their characters, view the leaderboard, and consult the rules.

        Attributes:
            __player (list): List used to store all players' information.

        Methods:
            __init__(): Initialises the Game object with an empty player list.
            play(): Starts the game by displaying the intro and running the main menu.
            intro(): Displays the game's introduction and welcome message.
            run_menu(): Displays the main menu and handles user input for game actions.
            add_player(): Adds a new player to the game.
            hunting(): Initiates a hunting expedition for a selected player.
            gamble(): Initiates a gambling session for a selected player.
            heal(): Handles the healing action for a selected player.
        """

    def __init__(self):
        """
        __init__(): Initialises the Game object with an empty player list.
        """
        self.__player = []

    def play(self):
        """
        Starts the game by displaying the intro and running the main menu.
        """
        self.intro()
        self.run_menu()

    def intro(self):
        """
        Displays the game's introduction and welcome message.
        """
        print("""
╔══════════════════════════════════════════════════════════════╗
║             ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄             ║
║                █  Welcome to Medieval Life  █                ║
║             ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀             ║
║                                                              ║
║ Prepare to embark on an epic journey through the Middle Ages!║
║ Hunt fearsome beasts, manage your coins wisely, and rise     ║
║ through the ranks to become a legendary hero.                ║
║                                                              ║
║ Will you be a skilled hunter, a cunning gambler, or perhaps  ║
║ a little bit of both? The choice is yours, brave adventurer! ║
║                                                              ║
║          Press Enter to begin your medieval saga...          ║
╚══════════════════════════════════════════════════════════════╝
        """)
        input()

    def run_menu(self):
        """
        Displays the main menu and handles user input for game actions.
        """
        while True:
            print("╔═════════════════════════════════╗")
            print("║            Main Menu            ║")
            print("╚═════════════════════════════════╝")
            print("What shall you do, brave adventurer?")
            print()
            print("(a) Recruit a new hero")
            print("(b) Hunting expedition")
            print("(c) Gamble at the tavern")
            print("(d) Seek the healer's aid")
            print("(e) Review the heroes' list")
            print("(f) Consult the rules")
            print("(g) Quit adventure\n")
            user_input = input("Your choice, m'lord? > ")
            if user_input in ("a", "b", "c", "d", "e", "f", "g"):
                if user_input == "a":
                    self.add_player()
                elif user_input == "b":
                    self.hunting()
                elif user_input == "c":
                    self.gamble()
                elif user_input == "d":
                    self.heal()
                elif user_input == "e":
                    board = Leaderboard(self.__player)
                    board.run()
                elif user_input == "f":
                    rules = Rules()
                    rules.read()
                elif user_input == "g":
                    print("Thank you for playing Medieval Life!")
                    break
            else:
                print(f"Holy grail! {user_input} is not a valid option from the menu.")
                print("Choose one option from the menu, brave adventurer!")
            print("")
        return user_input

    def add_player(self):
        """
        Adds a new player to the game.
        """
        print("╔══════════════════════════════════╗")
        print("║        Recruit a new hero        ║")
        print("╚══════════════════════════════════╝")
        print("What is the name of the new hero?")
        userInput = input("> ")
        if userInput == "":
            print("Sorry, the hero must have a name :)")
        elif len(userInput) > 10:
                print("The hero's name can have MAX 10 characters.")
        else:
            allNames = []
            for player in self.__player:
                allNames.append(player.get_name())
            if userInput in allNames:
                print("This hero has already been recruited.")
            else:
                self.__player.append(Player(userInput))
                print(f"Welcome, {userInput}!")
            print("Press Enter to return to the menu.")
            input()

    def hunting(self):
        """
        Initiates a hunting expedition for a selected player.
        """
        if len(self.__player) > 0:
            print("╔══════════════════════════════════╗")
            print("║        Hunting expedition        ║")
            print("╚══════════════════════════════════╝")
            print("Welcome to the Hunting season!")
            while True:
                print("Which hero is brave enough to risk their life?")
                print("════════════════════════════════════════════")
                print("Numb   Name      Level         HP         XP")
                print("════════════════════════════════════════════")
                for index, player in enumerate(self.__player):
                    print(f"{str(index + 1).rjust(4)}"
                          f"   "
                          f"{str(player.get_name()).ljust(10)}"
                          f"{str(player.get_level()).rjust(5)}"
                          f"{str(player.get_hp()).rjust(7)}"
                          f"/"
                          f"{str(player.get_hp_max())}"
                          f"{str(player.get_xp()).rjust(7)}"
                          f"/"
                          f"{str(player.get_xp_next_level()).ljust(4)}")
                print("════════════════════════════════════════════")
                hero = input("> ")
                try:
                    hero = int(hero)
                    if hero in range(1, len(self.__player) + 1):
                        hero -= 1
                        if self.__player[hero].get_coin() > 0:
                            hunt = Hunt(self.__player, hero)
                            hunt.start()
                            break
                    else:
                        print(f"M'lord! That hero is just a legend.\nSelect one hero in our kingdom.\n")
                except ValueError:
                    print("M'lord! Your choice must be a number within the range of heroes shown.\n")
        else:
            print("There are no heroes in your team. No heroes, no hunting!")

    def gamble(self):
        """
        Initiates a gambling session for a selected player.
        """
        if len(self.__player) > 0:
            print("╔══════════════════════════════════╗")
            print("║       Gamble at the tavern       ║")
            print("╚══════════════════════════════════╝")
            print("Welcome to the Gambling Tavern!")
            while True:
                print("Which hero dares to test their luck?")
                print("══════════════════════════════════════")
                print("Numb    Name                     Coins")
                print("══════════════════════════════════════")
                for index, player in enumerate(self.__player):
                    print(f"{str(index + 1).rjust(4)}"
                          f"    "
                          f"{str(player.get_name()).ljust(10)}"
                          f" "
                          f"{str(player.get_coin()).rjust(19)}")
                print("══════════════════════════════════════")
                hero = input("> ")
                try:
                    hero = int(hero)
                    if hero in range(1, len(self.__player) + 1):
                        hero -= 1
                        if self.__player[hero].get_coin() > 0:
                            print(f"Greetings, {self.__player[hero].get_name()}!")
                            while True:
                                print("How many shiny coins do you dare to sacrifice \n"
                                      f"to the gambling gods? ({self.__player[hero].get_coin()} available)")
                                bet = input("> ")
                                try:
                                    bet = int(bet)
                                except ValueError:
                                    print("Are you drunk? You can only bet coins here.\n")
                                else:
                                    if bet == 0:
                                        print("Ahaha, you can't bet 0 coins.\n")
                                    elif bet in range(1, self.__player[hero].get_coin() + 1):
                                        self.__player[hero].remove_coin(bet)
                                        gamble = Gamble(self.__player, hero, bet)
                                        gamble.start()
                                        break
                                    else:
                                        print("You don't have all those coins. (yet)\n")
                            break
                        else:
                            print("This brave hero's purse is completely empty. No gold, no games in this tavern. "
                                  "Who's got the coin?\n")
                    else:
                        print(f"M'lord! Your choice must be a number within the range of heroes shown.\n")
                except ValueError:
                    print("M'lord! Your choice must be a number within the range of heroes shown.\n")
        else:
            print("There are no heroes in your team. No heroes, no gamble!")

    def heal(self):
        """
        Handles the healing action for a selected player.
        """
        if len(self.__player) > 0:
            print("╔═════════════════════════════════╗")
            print("║      Seek the healer's aid      ║")
            print("╚═════════════════════════════════╝")
            while True:
                print("Which hero requires help from our divine healer?")
                print("══════════════════════════════════════")
                print("Numb   Name       Level             HP")
                print("══════════════════════════════════════")
                for index, player in enumerate(self.__player):
                    print(f"{str(index + 1).rjust(4)}"
                          f"   "
                          f"{str(player.get_name()).ljust(10)}"
                          f" "
                          f"{str(player.get_level()).rjust(5)}"
                          f"{str(player.get_hp()).rjust(10)}"
                          f"/"
                          f"{str(player.get_hp_max())}")
                print("══════════════════════════════════════")
                user_input = input("> ")
                try:
                    user_input = int(user_input)
                    if user_input in range(1, len(self.__player) + 1):
                        self.__player[user_input-1].heal()
                        print(f"{self.__player[user_input-1].get_name()}'s health has been restored!")
                        break
                    else:
                        print(f"M'lord! Your choice must be a number within the range of heroes shown.\n")
                except ValueError:
                    print("M'lord! Your choice must be a number within the range of heroes shown.\n")
        else:
            print("The realm awaits its heroes! Enlist a champion from the main menu.")
        print("Press Enter to return to the menu.")
        input()


class Player:
    """
        This class represents a player character.

        Each player has various attributes such as name, level, experience points (XP),
        health points (HP), attack, defence, and coins. Players can level up, gain XP,
        take damage, heal, and manage their coin balance.

        Attributes:
            __name (str): The name of the player.
            __level (int): The current level of the player.
            __xp (int): The current experience points of the player.
            __xp_next_level (int): The XP required to reach the next level.
            __hp (int): The current health points of the player.
            __hp_max (int): The maximum health points of the player.
            __attack (int): The attack power of the player.
            __defense (int): The defence power of the player.
            __coin (int): The current coin balance of the player.
            __level_up (bool): Flag to indicate if the player has levelled up.

        Methods:
            __init__(name): Initialises a new Player object with the given name.
            get_name(): Returns the player's name.
            get_level(): Returns the player's current level.
            get_xp(): Returns the player's current XP.
            get_xp_next_level(): Returns the XP required for the next level.
            get_hp(): Returns the player's current HP.
            get_hp_max(): Returns the player's maximum HP.
            get_attack(): Returns the player's attack.
            get_defense(): Returns the player's defence.
            take_damage(damage): Reduces the player's HP by the given damage amount.
            get_coin(): Returns the player's current coin balance.
            add_xp(xp): Adds XP to the player and handles level-ups.
            leveled_up(): Displays level-up information if the player has levelled up.
            remove_coin(coin): Removes coins from the player's balance.
            add_coin(coin): Adds coins to the player's balance.
            heal(): Restores the player's HP to maximum.
        """

    def __init__(self, name):
        """
        Initialises a new Player object with the given name.
        """
        self.__name = name
        self.__level = 1
        self.__xp = 0
        self.__xp_next_level = 100
        self.__hp = 100
        self.__hp_max = 100
        self.__attack = 100
        self.__defense = 100
        self.__coin = 100
        self.__level_up = False

    def get_name(self):
        """
        Returns the player's name.
        """
        return self.__name

    def get_level(self):
        """
        Returns the player's current level.
        """
        return self.__level

    def get_xp(self):
        """
        Returns the player's current XP.
        """
        return self.__xp

    def get_xp_next_level(self):
        """
        Returns the XP required for the next level.
        """
        return self.__xp_next_level

    def get_hp(self):
        """
        Returns the player's current HP.
        """
        return self.__hp

    def get_hp_max(self):
        """
        Returns the player's maximum HP.
        """
        return self.__hp_max

    def get_attack(self):
        """
        Returns the player's attack power.
        """
        return self.__attack

    def get_defense(self):
        """
        Returns the player's defence power.
        """
        return self.__defense

    def take_damage(self, damage):
        """
        Reduces the player's HP by the given damage amount.
        """
        self.__hp -= damage
        if self.__hp < 0:
            self.__hp = 0

    def get_coin(self):
        """
        Returns the player's current coin balance.
        """
        return self.__coin

    def add_xp(self, xp):
        """
        Adds XP to the player and handles level-ups.
        """
        self.__xp += xp
        level_before_xp = self.get_level()
        while self.__xp >= self.__xp_next_level:
            self.__level += 1
            self.__attack += 5
            self.__defense += 5
            self.__hp_max += 10
            self.__xp -= self.__xp_next_level
            self.__xp_next_level += 10
        if self.get_level() > level_before_xp:
            self.__level_up = True

    def leveled_up(self):
        """
        Displays level-up information if the player has levelled up.
        """
        if self.__level_up == True:
            self.__level_up = False
            print(f"{self.__name} leveled up.\n"
                  f"Level: {self.__level}\n"
                  f"XP: {self.__xp}/{self.__xp_next_level}\n"
                  f"HP: {self.__hp}/{self.__hp_max}\n"
                  f"Attack: {self.__attack}\n"
                  f"Defense: {self.__defense}")
        else:
            pass

    def remove_coin(self, coin):
        """
        Removes coins from the player's balance.
        """
        self.__coin -= coin

    def add_coin(self, coin):
        """
        Adds coins to the player's balance.
        """
        self.__coin += coin

    def heal(self):
        """
        Restores the player's HP to maximum.
        """
        self.__hp = self.__hp_max


class Action(ABC):
    """
        This is an abstract base class representing an action.
        It provides a template for specific action classes to inherit from.

        The Action class defines the basic structure for game actions, including
        setting up the player and position, and starting the action.

        Attributes:
            _player: The player performing the action.
            _position: The position of the participating player in the player list.

        Methods:
            __init__(player, position): Initialises the Action object with the player's list and the position
                                        of the chosen hero.
            set_player(player): Sets the player's list.
            set_position(position): Sets the position of the hero selected.
            start(): An abstract method to be implemented by subclasses to start the action.
        """

    @abstractmethod
    def __init__(self, player, position):
        """
        Initialises the Action object with the player's list and the position of the chosen hero.
        """
        self.set_player(player)
        self.set_position(position)

    def set_player(self, player):
        """
        Sets the player's list.
        """
        self._player = player

    def set_position(self, position):
        """
        Sets the position of the hero selected.
        """
        self._position = position

    @abstractmethod
    def start(self):
        """
        An abstract method to be implemented by subclasses to start the action.
        """
        pass


class Hunt(Action):
    """
        This class represents a hunting expedition in the Medieval Life game.
        It inherits from the Action class and implements the hunting mechanics.

        The Hunt class allows a player to encounter and fight monsters, potentially gaining
        experience points (XP) and coins upon victory, or facing defeat if overpowered.

        Attributes:
            Inherits attributes from the Action class:
            _player (list): The list of all players in the game.
            _position (int): The index of the participating player in the player list.

        Methods:
            __init__(player, position): Initialises the Hunt object with player list and position.
            start(): Begins the hunting expedition, encountering a random monster.
            fight(monster): Handles the turn-based combat between the player and the monster.
        """
    def __init__(self, player, position):
        """
        __init__(player, position): Initialises the Hunt object with player list and position.
        """
        super().__init__(player, position)

    def start(self):
        """
        start(): Begins the hunting expedition, encountering a random monster.
        """
        if self._player[self._position].get_hp() <= 0:
            print(f"{self._player[self._position].get_name()}, you're too weak to hunt. Please heal first!")
            return
        print(f"{self._player[self._position].get_name()}, you've embarked on a hunting expedition!")
        while True:
            monster = Monster(random.randint(0, 3))
            print(f"You encounter a {monster.get_name()} {monster.get_unicode()}!")
            self.fight(monster)
            break

    def fight(self, monster):
        """
        fight(monster): Handles the turn-based combat between the player and the monster.
        """
        while not monster.is_defeated() and self._player[self._position].get_hp() > 0:
            # Player's turn
            damage = self._player[self._position].get_attack() - monster.get_defense()
            if damage < 0:
                damage = 0
            monster.take_damage(damage)
            if monster.is_defeated():
                break
            # Monster's turn
            damage = monster.get_attack() - self._player[self._position].get_defense()
            if damage < 0:
                damage = 0
            self._player[self._position].take_damage(damage)
        # End of the turn
        if monster.is_defeated():
            print(f"\n🎉 Victory! You've defeated the {monster.get_name()} {monster.get_unicode()}!")
            xp_gained = monster.get_xp()
            coins_gained = monster.get_coin()
            self._player[self._position].add_xp(xp_gained)
            self._player[self._position].add_coin(coins_gained)
            self._player[self._position].leveled_up()
            print(f"You've gained {xp_gained} XP and {coins_gained} coins!")
        else:
            print(f"\n💀 Defeat! The {monster.get_name()} has bested you.")
            print("You've been returned to the village to recover.")
        print("Press Enter to return to the menu.")
        input()


class Monster():
    """
        This class represents a monster in the Medieval Life game.

        Each monster has various attributes such as name, unicode representation, health points (HP),
        attack, defence, experience points (XP), and coins. Monsters can take damage and be defeated
        by players during hunting expeditions.

        Attributes:
            name (str): The name of the monster.
            unicode (str): The unicode representation of the monster.
            hp (int): The current health points of the monster.
            attack (int): The attack power of the monster.
            defense (int): The defence power of the monster.
            xp (int): The experience points awarded for defeating the monster.
            coin (int): The coins awarded for defeating the monster.

        Methods:
            __init__(int): Initialises a new Monster object based on the given type.
            set_name(int): Sets the name of the monster based on the given type.
            set_unicode(int): Sets the unicode representation of the monster based on the given type.
            set_hp(int): Sets the health points of the monster based on the given type.
            set_attack(int): Sets the attack power of the monster based on the given type.
            set_defense(int): Sets the defense power of the monster based on the given type.
            set_xp(int): Sets the experience points awarded for defeating the monster based on the given type.
            set_coin(int): Sets the coins awarded for defeating the monster based on the given type.
            get_name(): Returns the name of the monster.
            get_unicode(): Returns the unicode representation of the monster.
            get_hp(): Returns the current health points of the monster.
            get_attack(): Returns the attack power of the monster.
            get_defense(): Returns the defence power of the monster.
            get_xp(): Returns the experience points awarded for defeating the monster.
            get_coin(): Returns the coins awarded for defeating the monster.
            take_damage(damage): Reduces the monster's health points by the given damage amount.
            is_defeated(): Checks if the monster's health points have reached zero or below.
        """
    def __init__(self, int):
        """
        Initialises a new Monster object based on the given type.
        """
        self.set_name(int)
        self.set_unicode(int)
        self.set_hp(int)
        self.set_attack(int)
        self.set_defense(int)
        self.set_xp(int)
        self.set_coin(int)

    def set_name(self, int):
        """
        Sets the name of the monster based on the given type.
        """
        if int == 0:
            self.name = "Flower"
        if int == 1:
            self.name = "Wolf"
        if int == 2:
            self.name = "Bear"
        if int == 3:
            self.name = "Dragon"

    def set_unicode(self, int):
        """
        Sets the unicode representation of the monster based on the given type.
        """
        if int == 0:
            self.unicode = "🌻"
        if int == 1:
            self.unicode = "🐺"
        if int == 2:
            self.unicode = "🐻"
        if int == 3:
            self.unicode = "🐲"

    def set_hp(self, int):
        """
        Sets the health points of the monster based on the given type.
        """
        if int == 0:
            self.hp = 1
        elif int == 1:
            self.hp = random.randint(35, 45)
        elif int == 2:
            self.hp = random.randint(40, 60)
        elif int == 3:
            self.hp = random.randint(80, 100)

    def set_attack(self, int):
        """
        Sets the attack power of the monster based on the given type.
        """
        if int == 0:
            self.attack = 0
        elif int == 1:
            self.attack = random.randint(105, 110)
        elif int == 2:
            self.attack = random.randint(110, 120)
        elif int == 3:
            self.attack = random.randint(130, 150)

    def set_defense(self, int):
        """
        Sets the defense power of the monster based on the given type.
        """
        if int == 0:
            self.defense = 0
        elif int == 1:
            self.defense = random.randint(80, 85)
        elif int == 2:
            self.defense = random.randint(85, 90)
        elif int == 3:
            self.defense = random.randint(90, 99)

    def set_xp(self, int):
        """
        Sets the experience points awarded for defeating the monster based on the given type.
        """
        if int == 0:
            self.xp = 10
        elif int == 1:
            self.xp = random.randint(30, 50)
        elif int == 2:
            self.xp = random.randint(50, 75)
        elif int == 3:
            self.xp = random.randint(75, 100)

    def set_coin(self, int):
        """
        Sets the coins awarded for defeating the monster based on the given type.
        """
        if int == 0:
            self.coin = random.randint(1, 3)
        elif int == 1:
            self.coin = random.randint(10, 20)
        elif int == 2:
            self.coin = random.randint(30, 50)
        elif int == 3:
            self.coin = random.randint(80, 90)

    def get_name(self):
        """
        Returns the name of the monster.
        """
        return self.name

    def get_unicode(self):
        """
        Returns the unicode representation of the monster.
        """
        return self.unicode

    def get_hp(self):
        """
        Returns the current health points of the monster.
        """
        return self.hp

    def get_attack(self):
        """
        Returns the attack power of the monster.
        """
        return self.attack

    def get_defense(self):
        """
        Returns the defence power of the monster.
        """
        return self.defense

    def get_xp(self):
        """
        Returns the experience points awarded for defeating the monster.
        """
        return self.xp

    def get_coin(self):
        """
        Returns the coins awarded for defeating the monster.
        """
        return self.coin

    def take_damage(self, damage):
        """
        Reduces the monster's health points by the given damage amount.
        """
        self.hp -= damage
        if self.hp < 0:
            self.hp = 0

    def is_defeated(self):
        """
        Checks if the monster's health points have reached zero or below.
        """
        return self.hp <= 0


class Gamble(Action):
    """
    This class represents a gambling session.
    It inherits from the Action class and implements the gambling mechanics.

    The Gamble class allows a player to wager coins and roll dice against the tavern,
    with the possibility of doubling their bet, losing it, or having it returned in case of a tie.

    Attributes:
        Inherits attributes from the Action class:
        _player (list): The list of all players in the game.
        _position (int): The index of the participating player in the player list.
        bet (int): The amount of coins the player is wagering.

    Methods:
        __init__(player, position, bet): Initialises the Gamble object with player list, position, and bet amount.
        start(): Begins the gambling session, allowing the player to roll dice and determine the outcome.
        roll_dice(strength): Rolls three dice with the given strength and returns the total points.
    """

    def __init__(self, player, position, bet):
        """
        Initialises the Gamble object with player list, position, and bet amount.
        """
        super().__init__(player, position)
        self.bet = bet

    def start(self):
        """
        Begins the gambling session, allowing the player to roll dice and determine the outcome.
        """
        while True:
            print("🎲 How strongly do you wish to throw your dice? (1-6)")
            strength = input("> ")
            try:
                strength = int(strength)
            except ValueError:
                print("Holy grail! That is not how you throw a dice! Try again.")
            else:
                if strength > 6:
                    print("Such strength would launch the dice to the next kingdom.\n"
                          "Hero, keep your throw within the tavern walls.")
                elif strength == 0:
                    print("A strength of zero? Even a gentle breeze could muster more might. Try again with some vigor!")
                else:
                    print(f"{self._player[self._position].get_name()}'s roll: ", end="")
                    hero_roll = self.roll_dice(strength)
                    print("Tavern's roll: ", end="")
                    house_roll = self.roll_dice(random.randint(1, 6))
                    print("")
                    if hero_roll > house_roll:
                        winnings = self.bet * 2
                        self._player[self._position].add_coin(winnings)
                        print(f"🍀 Fortune favors you! You've won {winnings} coins! 💰")
                    elif hero_roll < house_roll:
                        print("💀 Luck was not on your side this day. You lost your bet. 💸")
                    else:
                        self._player[self._position].add_coin(self.bet)
                        print("⚖️ A tie! Your coins are returned to you. 🤝")
                    print("Press Enter to return to the menu.")
                    input()
                    break

    def roll_dice(self, strength):
        """
        Rolls three dice with the given strength and returns the total points.
        """
        total = 0
        diceFace = ['', '⚀', '⚁', '⚂', '⚃', '⚄', '⚅']
        for _ in range(3):
            roll = random.randint(1, 6) + strength
            while roll > 6:
                roll -= 6
            total += roll
            print(f"{diceFace[roll]}", end="")
        print(f" for a total of {total} points.")
        return total


class Leaderboard():
    """
    This class represents the leaderboard in the Medieval Life game.
    It displays the list of all registered heroes, sorted by their level and experience points (XP).

    The Leaderboard class provides methods to show the top section, middle section (sorted players),
    and the bottom section of the leaderboard.

    Attributes:
        __player (list): The list of all players in the game.

    Methods:
        __init__(players): Initialises the Leaderboard object with the list of players.
        run(): Runs the leaderboard display by calling methods to show the top, middle, and bottom sections.
        show_top(): Displays the header of the leaderboard.
        show_middle(): Displays the sorted list of players based on their level and XP.
        show_bottom(): Displays the footer of the leaderboard and prompts the user to return to the menu.
    """

    def __init__(self, players):
        """
        Initialises the Leaderboard object with the list of players.
        """
        self.__player = players

    def run(self):
        """
        uns the leaderboard display by calling methods to show the top, middle, and bottom sections.
        """
        self.show_top()
        self.show_middle()
        self.show_bottom()

    def show_top(self):
        """
        Displays the header of the leaderboard.
        """
        print("╔═════════════════════════════════╗")
        print("║     Review the heroes' list     ║")
        print("╚═════════════════════════════════╝")
        print("══════════════════════════════════════")
        print("Name      Level           HP     coins")
        print("══════════════════════════════════════")

    def show_middle(self):
        """
        Displays the sorted list of players based on their level and XP.
        """
        player_stats = [(player, player.get_level(),
                         player.get_xp()) for player in self.__player]
        sorted_players = sorted(player_stats, key=lambda x: (- x[1], - x[2]))
        for player, level, xp in sorted_players:
            print(f"{str(player.get_name()).ljust(10)}"
                  f"{str(player.get_level()).rjust(5)}"
                  f"{str(player.get_hp()).rjust(9)}"
                  f"/"
                  f"{str(player.get_hp_max())}"
                  f"{str(player.get_coin()).rjust(10)}")

    def show_bottom(self):
        """
        Displays the footer of the leaderboard and prompts the user to return to the menu.
        """
        print("══════════════════════════════════════\n")
        while True:
            print("Press Enter to return to the menu.")
            user_input = input("> ")
            break


class Rules():
    """
        This class represents the rules section in the Medieval Life game.
        It provides instructions and guidelines on how to play the game.

        The Rules class displays a detailed explanation of the game's mechanics,
        including how to recruit heroes, go on hunting expeditions, gamble at the tavern,
        heal characters, review the leaderboard, and consult the rules.

        Methods:
            read(): Displays the game rules and instructions.
        """

    def read(self):
        """
        Displays the game rules and instructions.
        """
        print("\n╔═════════════════════════════════╗")
        print("║        Consult the rules        ║")
        print("╚═════════════════════════════════╝")
        print("Hey there! Welcome to Medieval Life!")
        print("Let me give you a quick rundown of how this game works. 📜")
        print("When you start the game, you'll see a menu with different options:\n")
        print("(a) Recruit a new hero: Add players to your team. Each hero starts at level 1 with 100 coins.")
        print("(b) Hunting expedition: Face four types of monsters to gain experience and coins. "
              "Higher levels yield better stats.")
        print("(c) Gamble at the tavern: Feeling lucky? Heroes can gamble their coins for a chance to win big./n"
              "    The game consist in throwing 3 dice. Based on the result, there can be three outputs.\n"
              "    1. If your total exceeds the tavern's roll, you double your bet.\n"
              "    2. If the tavern's roll is higher, you lose your bet.\n"
              "    3. In case of a tie, your bet is returned.")
        print("(d) Seek the healer's aid: Restore a hero's health to full strength.")
        print("(e) Review the heroes' list: View heroes ranked by level and experience.")
        print("(f) Consult the rules: Return to this screen for game instructions.")
        print("(g) Quit adventure: Exit the game.")
        print("\nEmbark on your medieval journey and may fortune favor the bold!")

        while True:
            print("Press Enter to return to the menu.")
            user_input = input("> ")
            break


if __name__ == "__main__":
    # Create an instance of the Game class called Medieval_Life
    Medieval_Life = Game()
    # Start the game by calling the play() method on the Medieval_Life instance
    Medieval_Life.play()