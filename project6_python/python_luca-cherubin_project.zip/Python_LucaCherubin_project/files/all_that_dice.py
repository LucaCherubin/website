#
# File: all_that_dice.py
# Description: All-That-Dice Game. The program can create 3 different dice games. To start, the user needs to create new
#              players. Players starts with 100 chips each and they can bet their chips to play a game alone or against
#              other players. If a player loose all the chips, they can't play anymore.
#              The program can also shows the leaderboard of the players and their stats.
# Author: Luca Cherubin
#


import random # Needed to generate random numbers
from abc import ABC, abstractmethod # Needed to create abstract classes/methods

class Dice():
    """
    Class used to represent a virtual dice with 6 faces.
    This class creates a certain amount of dice that the user needs to roll.
    The program will ask to enter a number from 0 to 5 and that will be added to a random number generated (1 to 6).
    The result will represent a face of a/multiple dice (a 6 face dice).

    Attributes:
        __numberOfDice (int): Number of dice that the user needs to use.
        __diceFace (list): List of 6 characters. Each of them represents a face of a die.
        __strength (int): Variable representing the strength of user to roll the dice.
            This number is used to modify the die's result.
        __diceResult (list): An empty list to store the result of the dice roll

    Methods:
        __init__(int): Method to initialise the object. Used to set the number of dice that will be used.
        run(): Method to run the program.
        update_strength(): Method to update the self.__strength attribute.
        throw_dice(): Method to throw all the dice available and store the result into the self.__diceResult attribute.
        get_dice_result(): Method to return a list with the result of all dice rolled.
        __str__(): Method to return a string representation off all the dice faces rolled based on __diceFace and __diceResult attributes.
    """

    def __init__(self, numberOfDice):
        """Variable representing the strength of user to roll the dice.
            This number is used to modify the die's result."""
        self.__numberOfDice = numberOfDice
        self.__diceFace = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅']
        self.__strength = -1
        self.__diceResult = []

    def run(self):
        """Method to run the program."""
        self.update_strength()
        self.throw_dice()

    def update_strength(self):
        """Method to update the self.__strength attribute."""
        while (0 <= self.__strength < 6) == False:
            print(f"How strong will you throw (0-5)?")
            self.__input = input("> ")
            try:
                self.__strength = int(self.__input)
            except ValueError:
                print("Invalid choice.")
            else:
                if 0 <= self.__strength <= 5:
                    break
                else:
                    print("Invalid choice.")

    def throw_dice(self):
        """Method to throw all the dice available and store the result into the self.__diceResult attribute."""
        for i in range(self.__numberOfDice):
            self.__diceResult.append([])
        for i in range(self.__numberOfDice):
            self.__diceResult[i] = random.randint(1, 6)
            self.__diceResult[i] += self.__strength
            if self.__diceResult[i] > 6:
                self.__diceResult[i] -= 6

    def get_dice_result(self):
        """Method to return a list with the result of all dice rolled."""
        return self.__diceResult

    def __str__(self):
        """Method to return a string representation off all the dice faces rolled based on __diceFace and __diceResult attributes."""
        self.__returnStr = ""
        for element in self.__diceResult:
            self.__returnStr += self.__diceFace[element - 1]
        return f"{self.__returnStr}"

class Player:
    """
    Class used to represent a single player.
    This class contains information about the name, number of chips available, game played and the number of game won.

    Attributes:
       __name (str): The name of the player.
       __chip (int): The number of chips available.
       __gamePlayed (int): The number of game played.
       __gameWon (int): The number of game won.

    Methods:
       __init__(str): Method to initialise the object. It'll set the name with the string passed to it.
       add_chips(): Method to add chips to the player.
       remove_chips(): Method to remove chips from the player.
       check_enough_chips(chips): Checks if chips available are >= with the parameter passed (True) or not (False).
       validate_number(): Method to check if the attribute is a number.
       lost_game(): Method used if the player lost a game (will only increase the number of game played of 1).
       won_game(): Method used if the player won a game (Increase game played, game won and will add the chips won).
       get_name(): Method to return the name of the player (__name).
       get_chips(): Method to return the number of chips available (__chip).
       get_game_played(): Method to return the number of game played (__gamePlayed).
       get_game_won(): Method to return the number of game won (__gameWon).
    """

    # A player will start with 100 chips and 0 games won and 0 games played
    def __init__(self, name):
        """Method to initialise the object. It'll set the name with the string passed to it."""
        self.__name = name
        self.__chip = 100
        self.__gamePlayed = 0
        self.__gameWon = 0

    def add_chips(self, chips):
        """Method to add chips to the player."""
        self.__chip += self.validate_number(chips)

    def remove_chips(self, chipsBet):
        """Method to remove chips from the player."""
        self.__chip -= self.validate_number(chipsBet)

    def check_enough_chips(self, chips):
        """Checks if chips available are >= with the parameter passed (True) or not (False)."""
        self.validate_number(chips)
        if self.__chip >= self.validate_number(chips):
            return True
        else:
            return False

    def validate_number(self, input):
        """Method to check if the attribute is a number."""
        try:
            input = int(input)
        except ValueError:
            print("This is not a number")
        else:
            return input

    def lost_game(self):
        """Method used if the player lost a game (will only increase the number of game played of 1)."""
        self.__gamePlayed += 1

    def won_game(self, totalBet):
        """Method used if the player won a game (Increase game played, game won and will add the chips won)."""
        self.__gamePlayed += 1
        self.__gameWon += 1
        self.add_chips(totalBet)

    def get_name(self):
        """Method to return the name of the player (__name)."""
        return self.__name

    def get_chips(self):
        """Method to return the number of chips available (__chip)."""
        return self.__chip

    def get_game_played(self):
        """Method to return the number of game played (__gamePlayed)."""
        return self.__gamePlayed

    def get_game_won(self):
        """Method to return the number of game won (__gameWon)."""
        return self.__gameWon

class AllThatDice:
    """
    Main class of the program.
    Here the user have different options. They can add new players, see the leaderboard or play a game.
    This class will ask which game to play and check if there is enough players (with enough chips to play) for it.
    The class will also make sure to don't create players with the same name or with only numbers in their name.

    Attributes:
       __player (list): List containing all the Player objects created.
       __gameName (str): Variable to store the game selected from user.
       __numberOfPlaying (int): Variable to store the number of players selected for a game.
       __availablePlayers (int): Variable to store the number of players that can play a game.
       __playerPosition (list): Variable to store the position of some players from the __player.
       __totalBet (int): Variable to store the total amount of chips bet from all the players.
       __userInput (str): Variable used to store the input entered from the user.
       __allNames (list): List that will be used to store all the names of every player registered.
       __found (bool): Boolean used when looking for a player' name in the __player list and see if it's found in it
       __double (bool): Boolean used to mark if the name is already been selected or not.

    Methods:
       __init__(str): Method to initialise the object.
       run(): Main method to run the program.
       show_intro(): Method to print the intro to the screen.
       start_menu(): This method will show the main.
       register_new_player(): Method used to add new players into the __player list after validating their name.
       validate_name(str): Method used to check if the name entered is an acceptable/valid name.
       check_before_game(): Register the players and their bet. Select and run a game with them after.
       choose_game_name(): Method used to select a game. Will check if enough players to play it before start it.
       check_available_players(): Counts how many players are available to play. Updates the __availablePlayers.
       ask_how_many_players(): Ask user how many players wants to participate. Updates the __numberOfPlaying.
       register_playing_players(): Will loop for each__numberOfPlaying and register player's name and their bet.
       ask_player_name(int): Asks to enter a name for the position (int) and checks if the name is available.
       find_player_position_in_the_list(str): Take the (str) and compares it with all player's name available.
            Once found it, saves their Index from the player's list and adds it to the __playerPosition list.
       ask_how_many_chips_to_bet(int): Ask used to enter how many chips to bet. If validated will update __totalBet.
       reset(): resets __gameName, __numberOfPlayers, __availablePlayers, __playerPosition, __totalBet & __userInput
       get_player(): Method to return the self.__player list attribute.
    """
    def __init__(self):
        """Method to initialise the object."""
        self.__player = []
        self.__gameName = ""
        self.__numberOfPlaying = 0
        self.__availablePlayers = 0
        self.__playerPosition = []
        self.__totalBet = 0
        self.__userInput = ""
        self.__allNames = []
        self.__found = False
        self.__double = False

    def run(self):
        """Main method to run the program."""
        self.show_intro()
        self.start_menu()

    def show_intro(self):
        """Method to print the intro to the screen."""
        print("\nWelcome to All-That-Dice!")
        print("Developed by Luca Cherubin\n")

    def start_menu(self):
        """start_menu(): This method will show the main."""
        while True:
            while self.__userInput not in ["r", "s", "p", "q"]:
                print("What would you like to do?")
                print("Enter the letter between () to select one.")
                print(" (r) register a new player")
                print(" (p) play a game")
                print(" (s) show the leader board")
                print(" (q) quit")
                self.__userInput = input("> ")
                if self.__userInput == "r":
                    self.register_new_player()
                elif self.__userInput == "s":
                    self.__choice = LeaderBoard()
                    self.__choice.run(self.__player)
                elif self.__userInput == "p":
                    self.check_before_game()
                elif self.__userInput == "q":
                    print("\nThank you for playing All-That-Dice!")
                else:
                    print("Sorry, invalid input\n")
            if self.__userInput == "q":
                break
            self.reset()

    def register_new_player(self):
        """Method used to add new players into the __player list after validating their name."""
        print("What is the name of the player?")
        self.__userInput = input("> ")
        if self.__userInput == "":
            print("Sorry, the name cannot be empty :)\n")
        else:
            if self.validate_name(self.__userInput) == True:
                self.__allNames = []
                for player in self.__player:
                    self.__allNames.append(player.get_name())
                if self.__userInput in self.__allNames:
                    print("Sorry, the name is already taken.\n")
                else:
                    self.__player.append(Player(self.__userInput))
                    print(f"Welcome, {self.__userInput}!\n")

    def validate_name(self, name):
        """Method used to check if the name entered is an acceptable/valid name."""
        try:
            name = int(name)
        except ValueError:
            if len(name) > 10:
                print("The name can have MAX 10 characters.\n")
                return False
            else:
                return True
        else:
            print("The name can not be a number. It must contains characters.\n")
            return False

    def check_before_game(self):
        """Register the players and their bet. Select and run a game with them after."""
        self.choose_game_name()
        if self.__gameName == "Not enough players":
            pass
        else:
            self.ask_how_many_players()
            self.register_playing_players()
            if self.__gameName == "o":
                self.__gameOn = OddOrEven(self.__player, self.__playerPosition, self.__totalBet)
            elif self.__gameName == "m":
                self.__gameOn = Maxi(self.__player, self.__playerPosition, self.__totalBet)
            elif self.__gameName == "b":
                self.__gameOn = Bunco(self.__player, self.__playerPosition, self.__totalBet)
            self.__gameOn.play()
        self.reset()

    def choose_game_name(self):
        """Method used to select a game. Will check if enough players to play it before start it."""
        self.check_available_players()
        while self.__gameName not in ("o", "m", "b"):
            print("Which game would you like to play?")
            print("  (o) Odd-or-Even")
            print("  (m) Maxi")
            print("  (b) Bunco")
            self.__gameName = input("> ")
            if self.__gameName == "o":
                if self.__availablePlayers >= 1:
                    print("Let's play the game of Odd-or-Even!")
                else:
                    print("Not enough players to play Odd-or-Even.\n")
                    self.__gameName = "Not enough players"
                    break
            elif self.__gameName == "m":
                if self.__availablePlayers >= 3:
                    print("Let's play the game of Maxi!")
                else:
                    print("Not enough players to play Maxi.\n")
                    self.__gameName = "Not enough players"
                    break
            elif self.__gameName == "b":
                if self.__availablePlayers >= 2:
                    print("Let's play the game of Bunco!")
                else:
                    print("Not enough players to play Bunco.\n")
                    self.__gameName = "Not enough players"
                    break
            else:
                print("Invalid choice.")

    def check_available_players(self):
        """Counts how many players are available to play. Updates the __availablePlayers."""
        for player in self.__player:
            if player.get_chips() > 0:
                self.__availablePlayers += 1

    def ask_how_many_players(self):
        """Ask user how many players wants to participate. Updates the __numberOfPlaying."""
        while True:
            if self.__gameName == "o":
                self.__numberOfPlaying = 1
                break
            elif self.__gameName == "m":
                print("How many players (3-5)?")
                self.__numberOfPlaying = input("> ")
                try:
                    self.__numberOfPlaying = int(self.__numberOfPlaying)
                except ValueError:
                    print("Please enter a number.")
                else:
                    if 3 <= self.__numberOfPlaying <= 5:
                        if self.__numberOfPlaying > self.__availablePlayers:
                            print("Not enough players to play Maxi.\n")
                        else:
                            break
                    else:
                        print("Invalid choice.")
            elif self.__gameName == "b":
                print("How many players (2-4)?")
                self.__numberOfPlaying = input("> ")
                try:
                    self.__numberOfPlaying = int(self.__numberOfPlaying)
                except ValueError:
                    print("Please enter a number.")
                else:
                    if 2 <= self.__numberOfPlaying <= 4:
                        if self.__numberOfPlaying > self.__availablePlayers:
                            print("Not enough players to play Bunco.\n")
                        else:
                            break
                    else:
                        print("Invalid choice.")
            else:
                print("Game not found")

    def register_playing_players(self):
        """Will loop for each__numberOfPlaying and register player's name and their bet."""
        for index in range(self.__numberOfPlaying):
            self.__found = False
            while self.__found == False:
                self.__found = False
                self.ask_player_name(index)
            self.ask_how_many_chips_to_bet(index)

    def ask_player_name(self, index):
        """Asks to enter a name for the position (int) and checks if the name is available."""
        print("What is the name of player", (index + 1), "?")
        self.find_player_position_in_the_list(input("> "))

    def find_player_position_in_the_list(self, name):
        """
        Take the (str) and compares it with all player's name available.
        Once found it, saves their Index from the player's list and adds it to the __playerPosition list.
        """
        self.__double = False
        self.__found = False
        for index, player in enumerate(self.__player):
            if player.get_name() == name:
                if index in self.__playerPosition:
                    print(f"{name} is already in the game.")
                    self.__double = True
                else:
                    if player.get_chips() == 0:
                        print(f"{name} has no chips and cannot play anymore.")
                        self.__double = True
                    else:
                        self.__found = True
                        if len(self.__playerPosition) == 0:
                            self.__playerPosition = [index]
                        else:
                            self.__playerPosition.append(index)
                        break
        if self.__double == False:
            if self.__found == False:
                print(f"There is no player named {name}.")

    def ask_how_many_chips_to_bet(self, index):
        """Ask used to enter how many chips to bet. If validated will update __totalBet."""
        while True:
            print(f"How many chips would you bid {self.__player[self.__playerPosition[index]].get_name()} (1-{self.__player[self.__playerPosition[index]].get_chips()})?")
            self.__userInput = input("> ")
            try:
                self.__userInput = int(self.__userInput)
            except ValueError:
                print("Please enter an integer.")
            else:
                if self.__userInput <= 0:
                    print("Invalid number of chips.")
                elif self.__player[self.__playerPosition[index]].check_enough_chips(self.__userInput) == False:
                    print("Invalid number of chips.")
                else:
                    self.__player[self.__playerPosition[index]].remove_chips(self.__userInput)
                    self.__totalBet += self.__userInput
                    break

    def reset(self):
        """resets __gameName, __numberOfPlayers, __availablePlayers, __playerPosition, __totalBet & __userInput"""
        self.__gameName = ""
        self.__numberOfPlaying = 0
        self.__availablePlayers = 0
        self.__playerPosition = []
        self.__totalBet = 0
        self.__userInput = ""

    def get_player(self):
        """Method to return the self.__player list attribute."""
        return self.__player

# If 0 players, an empty leaderboard will be created
class LeaderBoard:
    """
    Class used to print on the screen the players registered, their available chips and the number of game they have
    participated and won. The list is sorted in order from the player with more chips to the least. In case of multiple
    players with the same number of chips, the player with the highest __game_won/__game_played ratio will be
    shown first.

    Methods:
        run(list): Main method to run the program.
        show_top(): Method used to print the top of the leaderboard.
        show_middle(list): This method will sort the registered players in descending order based on chips and the
            __game_won/__game_played ratio.
        show_bottom(): Method used to print the bottom of the leaderboard.
    """

    def run(self, players):
        """Main method to run the program."""
        self.show_top()
        self.show_middle(players)
        self.show_bottom()

    def show_top(self):
        """Method used to print the top of the leaderboard."""
        print("")
        print("=============================")
        print("Name       Played  Won  Chips")
        print("=============================")

    def show_middle(self, players):
        """This method will sort the registered players in descending order based on chips and the
            __game_won/__game_played ratio."""
        player_stats = [(player, player.get_chips(),
                         player.get_game_won() / player.get_game_played() if player.get_game_played() > 0 else 0) for
                        player in players]
        sorted_players = sorted(player_stats, key=lambda x: (-x[1], -x[2]))
        for player, chips, win_rate in sorted_players:
            print(
                f"{str(player.get_name()).ljust(11)}{str(player.get_game_played()).rjust(6)}{str(player.get_game_won()).rjust(5)}{str(chips).rjust(7)}")

    def show_bottom(self):
        """Method used to print the bottom of the leaderboard."""
        print("=============================\n")

# Abstract class. Need to override the __init__, run and display_dice_face methods.
class Game(ABC):
    """
    This is an abstract class. It is used to create classes representing a die game.
    The following methods need to be overridden:
    - __init__()
    - play()
    - display_dice_face(diceFace: list)
    In this way, every child class will inherit the __init__() methods to save time coding the setters, will need to
    include the play() method to run the code (making it consistent) and will use the same method to print the dice face
    on screen.
    These are the common "characteristics" that each game needs to have.

    Attributes:
        __player (list): List used to store ALL players' information.
        __position (list): List used to store the position in the player list, of the participating players.
        __totalBet (int): A variable used to store the total bet of all players participating in the game.
        __numberOfDice (int): Here the number of dice needed for the game will be saved.

    Methods:
        __init__(list, list, int): Method used to set the player's information.
        set_player(player: list): Method used from __init__ to set the player's information.
        set_position(position: list)(): Method used from __init__ to set the position of participating players.
        set_total_bet(totalBet: int): Method used from __init__ to set the total bet from all the players.
        get_player(): Method used to return the player's information.
        get_position(): Method used to return the list of each player's position in the list of registered players.
        play(): Abstract method used to play the game.
        display_dice_face(diceFace: list): Abstract method used to display the dice face on screen.
    """

    @abstractmethod
    def __init__(self, player, position, totalBet):
        """Method used to set the player's information."""
        self.set_player(player)
        self.set_position(position)
        self.set_total_bet(totalBet)
        self._NumberOfDice = int

    def set_player(self, player):
        """Method used from __init__ to set the player's information."""
        self._player = player

    def set_position(self,position):
        """Method used from __init__ to set the position of participating players."""
        self._position = position

    def set_total_bet(self, totalBet):
        """Method used from __init__ to set the total bet from all the players."""
        self._totalBet = totalBet

    def get_player(self):
        """Method used to return the player's information."""
        return self._player

    def get_position(self):
        """Method used to return the list of each player's position in the list of registered players."""
        return self._position

    @abstractmethod
    def play(self):
        """Abstract method used to play the game."""
        pass

    @abstractmethod
    def display_dice_face(self, diceFace):
        """Abstract method used to display the dice face on screen."""
        pass

class OddOrEven(Game):
    """
    This is a class inheriting from the abstract class 'Game'. It is used to play the Odd or Even game.
    Only one player at the time can participate and only one die is used.
    The player is asked if the result of the dice will be an odd or even number.
    If the player gets the correct result they will get:
    - The number of chips they bet, doubled.
    - The number of game won will be increase by one.
    - The number of games in which they have participated, will be increase by one.
    In case they get the wrong result they will get:
    - The number of games in which they have participated, will be increased by one.
    After the game is completed, the program will go back to the main AllThatDice menu.

    Attributes:
        __player (list): List used to store ALL players' information.
        __position (list): List used to store the position in the player list, of the participating players.
        __totalBet (int): A variable used to store the total bet of all players participating in the game.
        __numberOfDice (int): Here the number of dice needed for the game will be saved.
        __userInput (str): A variable to save the user's input for the game.

    Methods:
        __init__(list, list, int): Method used to set the player's information and their bet.
            It needs to be implemented to override the abstract 'Game' class.
        display_dice_face(diceFace: list): Method used to display the dice face on screen.
            It needs to be implemented to override the abstract 'Game' class.
        get_number_of_dice(): Returns the number of dice used for the game.
        play(): Method used to play the game.
    """
    def __init__(self, player, position, totalBet):
        """Method used to set the player's information.
        It needs to be implemented to override the abstract Game class."""
        super().__init__(player, position, totalBet)
        self.__NumberOfDice = 1
        self.__userInput = ""

    def display_dice_face(self, diceFace):
        """Method used to display the dice face on screen.
        It needs to be implemented to override the abstract Game class."""
        print(diceFace)

    def get_number_of_dice(self):
        """Returns the number of dice used for the game."""
        return self.__NumberOfDice

    def play(self):
        """Method used to play the game."""
        print("Let the game begin!")
        print(f"Hey {self._player[self._position[0]].get_name()}, ", end="")
        while True:
            print("Odd (o) or Even (e)?")
            self.__userInput = input("> ")
            try:
                if self.__userInput == "o" or self.__userInput == "e":
                    break
                else:
                    self.__userInput = self.__userInput/'b'
            except TypeError:
                print("Invalid choice.")
        if self.__userInput == "e":
            self.__userInput = [2,4,6]
        elif self.__userInput == "o":
            self.__userInput = [1,3,5]
        dice = Dice(self.__NumberOfDice)
        dice.run()
        self.display_dice_face(dice.__str__())
        if dice.get_dice_result()[0] in self.__userInput:
            print(f"Congratulation, {self._player[self._position[0]].get_name()}! You win!\n")
            self._player[self._position[0]].won_game(self._totalBet * 2)
        else:
            print(f"Sorry, {self._player[self._position[0]].get_name()}! You lose!\n")
            self._player[self._position[0]].lost_game()

class Maxi(Game):
    """
    This is a class inheriting from the abstract class 'Game'. It is used to represent the Maxi game.
    3 to 5 players can participate at the same time, and two dice are used for this game.
    On each round, the player with the lowest sum of dice is eliminated until only one player is remaining.
    The winner of the game will get:
    - The sum of chips that have been bet for this game.
    - The number of game won will be increase by one.
    - The number of games in which they have participated, will be increase by one.
    For any other player:
    - The number of games in which they have participated, will be increased by one.
    After the game is completed, the program will go back to the main AllThatDice menu.

    Attributes:
        __player (list): List used to store ALL players' information.
        __position (list): List used to store the position in the player list, of the participating players.
        __totalBet (int): A variable used to store the total bet of all players participating in the game.
        __numberOfDice (int): Here the number of dice needed for the game will be saved.
        __diceResult (list): List to store the result of the dice game.
        __lowestResult (int): Variable used to store the lowest result from the dice, in each round.
        __lowestResultIndex (int): Variable used to store the index of the lowest result from the dice, in each round.
        __resultSum (int): Variable used to store the sum of each dice throw.

    Methods:
        __init__(list, list, int): Method used to set the participating player's information and total bet.
            It needs to be implemented to override the abstract 'Game' class.
        display_dice_face(list): Method used to display the dice face on screen.
            It needs to be implemented to override the abstract 'Game' class.
        get_number_of_dice(): Returns the number of dice used for the game.
        play(): Method used to play the game.
        result_round(): Method used to calculate the winner of each round based on the dice throw.
            The remaining players of each round are printed on the screen.
            If there is only one player left, the winner is announced.
    """
    def __init__(self, player, position, totalBet):
        """Method used to set the participating player's information and total bet.
            It needs to be implemented to override the abstract 'Game' class."""
        super().__init__(player, position, totalBet)
        self.__NumberOfDice = 2
        self.__DiceResult = []
        self.__lowestResult = 100
        self.__lowestResultIndex = 0
        self.__resultSum = 0

    def display_dice_face(self, diceFace):
        """Method used to display the dice face on screen.
            It needs to be implemented to override the abstract 'Game' class."""
        print(diceFace)

    def get_number_of_dice(self):
        """Returns the number of dice used for the game."""
        return self.__NumberOfDice

    def play(self):
        """Method used to play the game."""
        print("\nLet the game begin!")
        while len(self._position) > 1:
            for index in self._position:
                print(f"It's {self._player[index].get_name()}\'s turn.")
                dice = Dice(self.__NumberOfDice)
                dice.run()
                self.__DiceResult.append(dice.get_dice_result())
                self.display_dice_face(dice.__str__())
            self.result_round()
            self.__DiceResult = []

    def result_round(self):
        """Method used to calculate the winner of each round based on the dice throw.
            The remaining players of each round are printed on the screen.
            If there is only one player left, the winner is announced."""
        self.__lowestResult = 100
        self.__lowestResultIndex = 0
        for index, result in enumerate(self.__DiceResult):
            self.__resultSum = result[0] + result[1]
            if self.__resultSum < self.__lowestResult:
                self.__lowestResult = self.__resultSum
                self.__lowestResultIndex = index
        self._player[self._position[self.__lowestResultIndex]].lost_game()
        self._position.pop(self.__lowestResultIndex)
        if len(self._position) > 1:
            print(f"Players remaining: ", end="")
            for index, element in enumerate(self._position):
                print(f"{self._player[element].get_name()}", end="")
                if index < len(self._position)-1:
                    print(", ", end="")
            print()
        else:
            print(f"Congratulation, {self._player[self._position[0]].get_name()}! You win!\n")
            self._player[self._position[0]].won_game(self._totalBet)

class Bunco(Game):
    """
    This is a class inheriting from the abstract class 'Game'. It is used to represent the Bunco game.
    2 to 4 players can participate at the same time, and three dice are used for this game for a total of 6 rounds.
    A player is asked to throw their dice and the actual round is taken in consideration.
    The rules are as following:
    - For each die matching the current round, the player gets 1 point.
    - If all three dice are equal (but they don't match the round number), the player gets 5 points.
    - If all three dice are equal and they match the round number, the player gets 21 points.
    - Any other dice combination, the player doesn't get any points.
    - If the player gets any point, but they don't win the round, they need to throw the dice again.
    - If the player gets some points and win the round, the next player will throw the dice next.
    - If the player doesn't get any points, the next player needs to throw the dice next.
    To win a round, the players needs to reach 21 points. The player who wins more rounds, wins the game.
    If multiple players have won the same numbers of rounds, the winner is based on the number of Bunco they had, and
    if that is a tie, the total points scored will be considered.
    The winner of the game will get:
    - The sum of chips that have been bet for this game.
    - The number of game won will be increase by one.
    - The number of games in which they have participated, will be increase by one.
    For any other player:
    - The number of games in which they have participated, will be increased by one.
    After the game is completed, the program will go back to the main AllThatDice menu.

    Attributes:
        __player (list): List used to store ALL players' information.
        __position (list): List used to store the position in the player list, of the participating players.
        __totalBet (int): A variable used to store the total bet of all players participating in the game.
        __maximumRound (int): Used to represent the number of rounds that needs to be played to complete the game.
        __scoreToWin (int): Used to represent the integer necessary to reach to win the round.
        __numberOfDice (int): Here the number of dice needed for the game will be saved.
        __diceResult (list): List to store the result of the dice game.
        __playerPoints (list): List to store the points gained in each round for every player. List of a list.
        __totalPoints (list): List to store the sum of points gained by players. It resets every round.
        __buncoCount (list): List to store how many Buncos each player have.
        __won (list): List to store how many rounds each player has won.
        __winner (int): Used to store the position of the player who won the game.
        __round (int): Variable to count the number of the current round.
        __inTheGame (bool): Boolean used to indicate when the game is completed.
        __nextTurn (bool): Boolean used to indicate if the turn is over.
        __thisRoundPoint (int): Variable used to count how many points gained during this dice throw.
        __maxWinner (int): Used to compare the numbers of rounds won.
        __maxBunco (int): Used to compare the numbers of Buncos each player have.
        __maxPoints (int): Used to compare the number of points gained of each player.

    Methods:
        __init__(list, list, int): Method used to set the participating player's information and total bet.
            It needs to be implemented to override the abstract 'Game' class.
        display_dice_face(list): Method used to display the dice face on screen.
            It needs to be implemented to override the abstract 'Game' class.
        get_number_of_dice(): Returns the number of dice used for the game.
        play(): Method used to start playing the game. Neet to use this to be able to use the class correctly.
        result_round(): Method used to calculate how many points are gained in each dice throw. It returns the number.
        print_phrase(int, int): Method to print how many points have been gained with this dice throw.
            The message changed, based on the parameters passed to it.
        print_board(list, list, list, int): Method used to call all the other methods needed to print the result's board
        board_separator(int): This method prints the separator of the result's board.
        board_top(list, list): This method prints the top part of the result's board.
        board_middle(list): This method prints the points accumulated from all the players, for each round.
        board_total(): This method prints the total points accumulated for each player.
        board_bunco(list): This method prints the total number of Bunco achieved for each player.
        board_bottom(list): This method prints the winner of the game with the points/Buncos/round won.

    """
    def __init__(self, player, position, totalBet):
        """Method used to set the participating player's information and total bet.
            It needs to be implemented to override the abstract 'Game' class."""
        super().__init__(player, position, totalBet)
        self.__maximumRound = 6
        self.__scoreToWin = 21
        self.__numberOfDice = 3
        self.__diceResult = []
        self.__playerPoints = [[0 for i in range(len(self._position))] for x in range(self.__maximumRound)]
        self.__totalPoints = [0 for i in range(len(self._position))]
        self.__buncoCount = [0 for i in range(len(self._position))]
        self.__won = [0 for i in range(len(self._position))]
        self.__winner = 0
        self.__round = int
        self.__inTheGame = bool
        self.__nextTurn = bool
        self.__thisRoundPoint = int

    def display_dice_face(self, diceFace):
        """Method used to display the dice face on screen.
            It needs to be implemented to override the abstract 'Game' class."""
        print(diceFace)

    def get_Number_of_dice(self):
        """Returns the number of dice used for the game."""
        return self.__numberOfDice

    def play(self):
        """Method used to start playing the game. Neet to use this to be able to use the class correctly."""
        self.__round = 0
        print("\n<Round ", self.__round + 1, ">")
        self.__inTheGame = True
        while self.__inTheGame == True:
            for index, element in enumerate(self._position):
                print(f"It's {self._player[element].get_name()}\'s turn.")
                self.__nextTurn = False
                while self.__nextTurn == False:
                    dice = Dice(self.__numberOfDice)
                    dice.run()
                    self.display_dice_face(dice.__str__())

                    self.__thisRoundPoint = self.result_round(dice.get_dice_result(), self.__round + 1, index)
                    self.__playerPoints[self.__round][index] += self.__thisRoundPoint
                    self.__totalPoints[index] += self.__thisRoundPoint

                    print(self.print_phrase(self.__thisRoundPoint,1), self.print_phrase(self.__playerPoints[self.__round][index],2))

                    if self.__thisRoundPoint != 0:
                        if self.__playerPoints[self.__round][index] < self.__scoreToWin:
                            print(f"Keep playing {self._player[element].get_name()}.")
                        else:
                            print(f"{self._player[element].get_name()} is the winner in round {self.__round + 1}!")
                            self.__won[index] += 1
                            self.__round += 1
                            if self.__round != self.__maximumRound:
                                print("\n<Round ", self.__round + 1, ">")
                            self.__nextTurn = True
                    else:
                        self.__nextTurn = True
                if self.__round == self.__maximumRound:
                    self.__inTheGame = False
                    break
        self.print_board(self._player, self._position, self.__playerPoints, self.__buncoCount)

    def result_round(self, diceRolled, roundNumber, index):
        """Method used to calculate how many points are gained in each dice throw. It returns the number."""
        self.__points = 0
        if (diceRolled[0] == diceRolled[1] and diceRolled[1] == diceRolled[2]):
            if diceRolled[0] == roundNumber:
                self.__points = 21
                print("Bunco!")
                self.__buncoCount[index] += 1
                return self.__points
            else:
                self.__points = 5
                return self.__points
        for face in diceRolled:
            if face == roundNumber:
                self.__points += 1
        return self.__points

    def print_phrase(self, points, part):
        """Method to print how many points have been gained with this dice throw.
            The message changed, based on the parameters passed to it."""
        self.__toPrint = ""
        if part == 1:
            if points == 0:
                self.__toPrint = "You earned no points, "
            elif points == 1:
                self.__toPrint = "You earned 1 point, "
            else:
                self.__toPrint = f"You earned {points} points, "
        elif part == 2:
            self.__toPrint = f"{points} points in total."
        return self.__toPrint

    def print_board(self, players, position, points, bunco):
        """Method used to call all the other methods needed to print the result's board"""
        print()
        self.board_separator(len(position))
        self.board_top(players, position)
        self.board_separator(len(position))
        self.board_middle(points)
        self.board_separator(len(position))
        self.board_total()
        self.board_separator(len(position))
        self.board_bunco(bunco)
        self.board_separator(len(position))
        self.board_bottom(players)

    def board_separator(self, index):
        """This method prints the separator of the result's board."""
        print("=====" + "===========" * index)

    def board_top(self, players, position):
        """This method prints the top part of the result's board."""
        print("Round", end="")
        for i in position:
            name = players[i].get_name()
            print(name.rjust(11), end="")
        print()

    def board_middle(self, points):
        """This method prints the points accumulated from all the players, for each round."""
        for index, element in enumerate(points):
            print(f"    {index + 1}", end="")
            for score in element:
                print(f"{str(score).rjust(11)}", end="")
            print()

    def board_total(self):
        """This method prints the total points accumulated for each player."""
        print("Total", end="")
        for index, element in enumerate(self.__totalPoints):
            print(f"{str(element).rjust(11)}", end="")
        print()

    def board_bunco(self, bunco):
        """This method prints the total number of Bunco achieved for each player."""
        print("Bunco", end="")
        for index, element in enumerate(bunco):
            print(f"{str(element).rjust(11)}", end="")
        print()

    def board_bottom(self, players):
        """This method prints the winner of the game with the points/Buncos/round won."""
        self.__maxWinner = 0
        self.__maxBunco = 0
        self.__maxPoints = 0
        for index, element in enumerate(self.__won):
            if self.__maxWinner < element:
                self.__winner = index
                self.__maxWinner = element
                self.__maxBunco = self.__buncoCount[index]
                self.__maxPoints = self.__totalPoints[index]
            elif self.__maxWinner == element:
                if self.__maxBunco < self.__buncoCount[index]:
                    self.__winner = index
                    self.__maxBunco = self.__buncoCount[index]
                    self.__maxPoints = self.__totalPoints[index]
                elif self.__maxBunco == self.__buncoCount[index]:
                    if self.__maxPoints < self.__totalPoints[index]:
                        self.__winner = index
                        self.__maxPoints = self.__totalPoints[index]
        print(f"{players[self._position[self.__winner]].get_name()} won {self.__won[self.__winner]} rounds, scoring {self.__totalPoints[self.__winner]} points, with {self.__buncoCount[self.__winner]} Bunco", end="")
        if self.__buncoCount[self.__winner] < 2:
            print(".")
        else:
            print("s.")
        print(f"Congratulations, {players[self._position[self.__winner]].get_name()}! You win!\n")
        for index, element in enumerate(players):
            if self._position[self.__winner] == index:
                players[index].won_game(self._totalBet)
            else:
                players[index].lost_game()

atd = AllThatDice()
atd.run()