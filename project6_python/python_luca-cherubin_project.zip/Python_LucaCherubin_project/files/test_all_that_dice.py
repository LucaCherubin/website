import unittest
from all_that_dice import Dice

class TestDice(unittest.TestCase):

    def test_get_dice_result(self):
        dice = Dice(1)
        result = dice.get_dice_result()
        self.assertIsInstance(result, list)

    def test_get_dice_result(self):
        dice = Dice(1)
        dice.throw_dice()
        result = dice.get_dice_result()
        self.assertIn(result[0], [0,1,2,3,4,5])

    def test_get_face(self):
        dice = Dice(1)
        self.assertIsInstance(dice.__str__(), str)
####################################################################################################################
from all_that_dice import Player

class TestPlayer(unittest.TestCase):

    def test_name(self):
        player = Player('Luca')
        self.assertIs(player.get_name(), 'Luca')

    def test_name_str(self):
        player = Player('name')
        self.assertIsInstance(player.get_name(), str)

    def test_initialising_chips_to_100(self):
        player = Player('Luca')
        self.assertIs(player.get_chips(), 100)

    def test_initialising_player(self):
        player = Player('Luca')
        self.assertEqual([player.get_name(), player.get_chips(), player.get_game_won(), player.get_game_played()], ['Luca', 100, 0, 0])

####################################################################################################################
from all_that_dice import AllThatDice

class TestAllThatDice(unittest.TestCase):

    def test_validate_name(self):
        atd = AllThatDice()
        self.assertTrue(atd.validate_name('Luca'))


    def test_get_players(self):
        atd = AllThatDice()
        self.assertIsInstance(atd.get_player(), list)

####################################################################################################################
from all_that_dice import LeaderBoard

class TestLeaderBoard(unittest.TestCase):

    def test_validate_name(self):
        lead = LeaderBoard()
        self.assertEqual(lead.show_top(), None)

    def test_validate_name(self):
        lead = LeaderBoard()
        self.assertEqual(lead.show_bottom(), None)

####################################################################################################################
from all_that_dice import Game
class TestGame(unittest.TestCase):
    def test_get_player(self):
        game = OddOrEven([], [1,2], 100)
        self.assertEqual(game.get_player(), [])

    def test_get_position(self):
        game = OddOrEven([], [1,2], 100)
        self.assertEqual(game.get_position(), [1,2])

####################################################################################################################
from all_that_dice import OddOrEven

class TestOddOrEven(unittest.TestCase):
    def test_number_of_dice(self):
        game = OddOrEven([], [1,2], 100)
        self.assertEqual(game.get_number_of_dice(), 1)

    def test_display_dice_face(self):
        game = OddOrEven([], [1,2], 100)
        self.assertEqual(game.display_dice_face('⚀'), None)

####################################################################################################################
from all_that_dice import Maxi

class TestMaxi(unittest.TestCase):
    def test_number_of_dice(self):
        game = Maxi([], [1, 2], 100)
        self.assertEqual(game.get_number_of_dice(), 2)

    def test_number_of_dice(self):
        game = Maxi([], [1, 2], 100)
        self.assertNotEqual(game.get_number_of_dice(), 1)


####################################################################################################################
from all_that_dice import Bunco

class TestBunco(unittest.TestCase):
    def test_number_of_dice(self):
        game = Bunco([], [1, 2], 100)
        self.assertEqual(game.get_Number_of_dice(), 3)

    def test_print_phrase(self):
        game = Bunco([], [1, 2], 100)
        self.assertEqual(game.print_phrase(0, 1), "You earned no points, ")


if __name__ == '__main__':
    unittest.main()
