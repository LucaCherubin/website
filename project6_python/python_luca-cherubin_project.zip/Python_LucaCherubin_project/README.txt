
		                ALL-THAT-DICE

All-That-Dice is a Python program that simulates a dice game where 
players can register, bet their chips, and play various dice games.
The program offers three different game modes: 
Odd-or-Even, Maxi, and Bunco.


0. FILE TO USE
For a better user experience, open the all_that_dice.cpython-312 file

1. FEATURES
- Player Registration: Players can register their names and start 
with 100 chips.
- Leaderboard: The program displays a leaderboard that shows the 
players' names, number of games played, number of games won, 
and remaining chips.
- Game Selection: Players can choose to play one of the three available
game modes: Odd-or-Even, Maxi, or Bunco.
- Betting System: Before starting a game, players can bet a certain 
number of chips from their available chips.
- Game Mechanics:
    - Odd-or-Even: A single player guesses whether the result of 
    rolling a die will be odd or even.
    - Maxi: Three to five players take turns rolling two dice. 
    The player with the lowest sum of dice values is eliminated. 
    The last remaining player wins.
    - Bunco: Two to four players roll three dice. Points are awarded 
    based on the round number and matching dice values. 
    The first player to reach 21 points wins.
- Game Results: After each game, the program displays the winner 
and updates the players' chips and game statistics accordingly.


2. REQUIREMENTS
- Python 3.x


3. USAGE
1. Clone or download the repository.
2. Navigate to the project directory.
3. Run the chely167.py file using Python.
4. Follow the on-screen instructions to register players, 
choose a game mode, and play the game.


4. CODE STRUCTURE
The program is organized into several classes:
- AllThatDice: The main class that handles the game menu, 
player registration, and game selection.
- Player: Represents a player with attributes like name, chips, 
and game statistics.
- LeaderBoard: Displays the leaderboard with players' names, 
games played, games won, and remaining chips.
- Game: An abstract base class that defines the common interface 
for the game classes.
- OddOrEven, Maxi, and Bunco: Concrete classes that inherit from 
Game and implement the respective game logic.
- Dice: Represents a virtual die and handles rolling and displaying 
the dice results.

5. DESIGN PRINCIPLES
The All-That-Dice program follows several object-oriented design 
principles to ensure code reusability, maintainability, and 
extensibility.

- POLYMORPHISM:
Polymorphism is achieved through the use of the abstract base class 
Game and its concrete subclasses OddOrEven, Maxi, and Bunco. 
These subclasses implement the abstract play and displayDiceFace 
methods defined in the base class, allowing them to exhibit 
different behaviors while sharing a common interface.

- INHERITANCE:
Inheritance is used extensively in the program. 
The OddOrEven, Maxi, and Bunco classes inherit from the abstract base 
class Game, inheriting its common attributes and methods. 
This promotes code reuse and allows for the implementation of 
game-specific logic in the subclasses.
Additionally, the Dice class is used as a composition within the game 
classes, providing a reusable implementation for rolling and 
managing dice.

- ABSTRACTION:
The class Game is an abstract base class that defines the common 
interface for all game classes. It declares abstract methods 
(play and displayDiceFace) that must be implemented by the concrete 
subclasses. This abstraction allows the program to work with game 
objects without needing to know the specific implementation details of each game.
The Dice class also provides an abstraction for rolling and managing 
dice, encapsulating the implementation details and exposing a simple 
interface for other classes to use.
By following these principles, the All-That-Dice program achieves code 
modularity, extensibility, and maintainability. 
New game types can be added by creating new subclasses of Game without 
modifying the existing code. The use of polymorphism and inheritance 
promotes code reuse and allows for a consistent interface across 
different game types.


6. AUTHOR:
- Luca Cherubin


7. CONTACTS:
lucacherubin27@gmail.com